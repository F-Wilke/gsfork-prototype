#define _GNU_SOURCE
#include "kernels.h"
#include <asm/prctl.h>
#include <errno.h>
#include <inttypes.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

static void die(const char *s) { perror(s); exit(1); }
static uint64_t ns(clockid_t c) {
    struct timespec t;
    if (clock_gettime(c, &t)) die("clock_gettime");
    return (uint64_t)t.tv_sec * 1000000000ULL + t.tv_nsec;
}
static uint64_t rand64(uint64_t *s) { *s ^= *s << 13; *s ^= *s >> 7; *s ^= *s << 17; return *s; }
static void set_gs(uintptr_t base) {
    if (syscall(SYS_arch_prctl, ARCH_SET_GS, base)) die("ARCH_SET_GS");
}
int main(int argc, char **argv) {
    if (argc != 6) {
        fprintf(stderr, "usage: %s sum|update|avx2|chase native|zero|shift bytes rounds cpu\n", argv[0]);
        return 2;
    }
    const char *kernel = argv[1], *mode = argv[2];
    size_t bytes = strtoull(argv[3], NULL, 0), rounds = strtoull(argv[4], NULL, 0);
    int cpu = atoi(argv[5]);
    int shifted = !strcmp(mode, "shift"), chase = !strcmp(kernel, "chase");
    int mutating = !strcmp(kernel, "update") || !strcmp(kernel, "avx2");
    if ((strcmp(mode,"native") && strcmp(mode,"zero") && !shifted) ||
        (!chase && !mutating && strcmp(kernel,"sum")) || bytes < 4096 ||
        bytes > (1ULL<<28) || bytes % 4096 || !rounds || cpu < 0 || cpu >= CPU_SETSIZE) return 2;
    if (!strcmp(kernel,"avx2") && !__builtin_cpu_supports("avx2")) {
        fprintf(stderr, "AVX2 not supported\n"); return 77;
    }
    cpu_set_t cpus;
    CPU_ZERO(&cpus); CPU_SET(cpu, &cpus);
    if (sched_setaffinity(0, sizeof(cpus), &cpus)) die("sched_setaffinity");
    const uintptr_t logical = 0x1000000000ULL, delta = 0x10000000000ULL;
    void *parent = mmap((void *)logical, bytes, PROT_READ|PROT_WRITE,
                        MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE, -1, 0);
    if (parent == MAP_FAILED) die("mmap parent");
    void *child = mmap((void *)(logical+delta), bytes, PROT_READ|PROT_WRITE,
                       MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE, -1, 0);
    if (child == MAP_FAILED) die("mmap child");
    // Avoid dependence on transparent hugepage policy across samples.
    if (madvise(parent, bytes, MADV_NOHUGEPAGE) || madvise(child, bytes, MADV_NOHUGEPAGE)) die("madvise");
    size_t n = bytes / (chase ? sizeof(struct node) : sizeof(uint64_t));
    uint64_t initial_sum = 0;
    if (chase) {
        size_t *order = malloc(n * sizeof(*order));
        if (!order) die("malloc");
        for (size_t i=0; i<n; ++i) order[i] = i;
        uint64_t state = 0x61a231bc97ULL;
        for (size_t i=n-1; i>0; --i) {
            size_t j = rand64(&state) % (i+1), t=order[i]; order[i]=order[j]; order[j]=t;
        }
        struct node *p = parent;
        for (size_t i=0; i<n; ++i) {
            p[order[i]].next = &p[order[(i+1)%n]];
            p[i].value = i+1; initial_sum += i+1;
        }
        free(order);
    } else {
        uint64_t *p = parent;
        for (size_t i=0; i<n; ++i) { p[i] = i+1; initial_sum += i+1; }
    }
    memcpy(child, parent, bytes); // Stored pointer bits are copied without fixups.
    unsigned long saved_gs;
    if (syscall(SYS_arch_prctl, ARCH_GET_GS, &saved_gs)) die("ARCH_GET_GS");
    set_gs(shifted ? delta : 0);
    // A missed prefix in shifted code faults instead of silently reading parent data.
    if (shifted && mprotect(parent, bytes, PROT_NONE)) die("mprotect");
    uint64_t (*fn)(uint64_t *, size_t, size_t) = kernel_sum;
    if (!strcmp(kernel,"update")) fn=kernel_update;
    if (!strcmp(kernel,"avx2")) fn=kernel_avx2;
    for (int i=0; i<3; ++i) {
        if (chase) (void)kernel_chase(parent,n,1); else (void)fn(parent,n,1);
    }
    int cpu_before = sched_getcpu();
    uint64_t wall0 = ns(CLOCK_MONOTONIC_RAW), thread0 = ns(CLOCK_THREAD_CPUTIME_ID);
    uint64_t result = chase ? kernel_chase(parent,n,rounds) : fn(parent,n,rounds);
    uint64_t thread_ns = ns(CLOCK_THREAD_CPUTIME_ID)-thread0;
    uint64_t wall_ns = ns(CLOCK_MONOTONIC_RAW)-wall0;
    int cpu_after = sched_getcpu();
    set_gs(saved_gs);
    if (shifted && mprotect(parent, bytes, PROT_READ|PROT_WRITE)) die("restore parent");
    uint64_t expected = mutating ? n+rounds+3 : initial_sum*rounds;
    int ok = result == expected && cpu_before == cpu && cpu_after == cpu;
    if (mutating) {
        const uint64_t *p = parent, *c = child;
        for (size_t i=0; i<n; ++i) {
            uint64_t want_p = i+1+(shifted ? 0 : rounds+3);
            uint64_t want_c = i+1+(shifted ? rounds+3 : 0);
            if (p[i] != want_p || c[i] != want_c) { ok=0; break; }
        }
    } else if (memcmp(parent, child, bytes)) ok=0;
    printf("{\"kernel\":\"%s\",\"mode\":\"%s\",\"bytes\":%zu,\"rounds\":%zu,"
           "\"cpu\":%d,\"wall_ns\":%" PRIu64 ",\"thread_ns\":%" PRIu64 ","
           "\"checksum\":%" PRIu64 ",\"expected\":%" PRIu64 ",\"verified\":%s,"
           "\"gs_base\":%" PRIuPTR ",\"logical_base\":%" PRIuPTR "}\n",
           kernel,mode,bytes,rounds,cpu,wall_ns,thread_ns,result,expected,
           ok ? "true":"false",shifted ? delta:0,logical);
    munmap(parent,bytes); munmap(child,bytes);
    return ok ? 0 : 1;
}
